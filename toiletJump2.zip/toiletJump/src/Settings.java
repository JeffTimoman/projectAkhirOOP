public class Settings {
    public static int pipeSpeed = 30, distance = 100;
    public static double gravity = 0.25;
}
